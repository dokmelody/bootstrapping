# Test Mermaid diagram in markdown

The following is a diagram.

<p>
    <foreign outputclass="embed-mermaid-diagram">graph TD;
	A-->B;
	A-->C;
	B-->D;
	C-->D;</foreign>
</p>
